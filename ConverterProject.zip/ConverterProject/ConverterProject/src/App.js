import React, { useState } from "react";
import Converter from "./Converter";
function App() {

  function farenheitToCelsius(fahrenheit) {
    return (fahrenheit * 9) / 5 + 32;

  }
  function celsiusToFahrenheit(celsius) {
    return (celsius - 32) * (5 / 9);
  }
  function gallonToLiter(gallon) {
    return (gallon * 3.785)

  } function literToGallon(liter) {
    return (liter / 3.785)
  }
  function milesToKilometers(miles) {
    return (miles * 0.621371)

  } function kilometerToMiles(kilometers) {
    return (kilometers / 0.621371)
  }

  return (
    <article>
      <div className="Min">
        <div className="Box">
          <div className="Title">Converter</div>
          <Converter unit1="Celsius" unit2="Fahrenheit" convertFunction1={farenheitToCelsius} convertFunction2={celsiusToFahrenheit} />
          <Converter unit1="Gallon" unit2="Liter" convertFunction1={gallonToLiter} convertFunction2={literToGallon} />
          <Converter unit1="Miles" unit2="Kilometers" convertFunction1={kilometerToMiles} convertFunction2={milesToKilometers} />
        </div>
      </div>
    </article>
  )
}
export default App;



  // function distansConverter(value, unit) {
  //   if (unit === "Miles")
  //   {
  //     return (value / 0.621371)
  //   }
  //   else if (unit === "Kilometers")
  //    {
  //     return (value * 0.621371)
  //   }
  //   else 
  //   return console.log("asd");
  // }

