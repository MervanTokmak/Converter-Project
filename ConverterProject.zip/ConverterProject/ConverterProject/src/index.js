import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import './index.css'


function loadGoogleFonts() {
  const link = document.createElement('link');
  link.rel = "stylesheet"
  link.href = "https://fonts.googleapis.com/css2?family=Luckiest+Guy&display=swap"
  document.head.appendChild(link);
}

loadGoogleFonts();

ReactDOM.render(
  <React.StrictMode>
    <App/>
  </React.StrictMode>,
  document.getElementById('root')
);
